# registratoridicassaroma.com
Versione aggiornata del sito vetrina.

Modifiche principali:
- logo Longo reale inserito nell'header e footer;
- hero con immagine di registratore/stampante;
- sezione prodotti ampliata;
- sezione marchi con Epson, Custom, ItalRetail, Think To IT, System Retail e Axon Micrelec;
- grafica responsive desktop/mobile;
- CTA e contatti più visibili;
- meta description SEO aggiornata.
