# registratoridicassaroma.com

Sito vetrina statico pronto per GitHub/Vercel.

## File
- index.html
- styles.css
- script.js

## Pubblicazione
Caricare i file nella root del repository. Se il repository è collegato a Vercel, il deploy partirà automaticamente.
